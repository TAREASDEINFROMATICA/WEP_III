<?php

$cadena ="hola mundo";
echo "lonjitud $cadena -> ".strlen($cadena)."<br>"; //el strlen sirve para la cantidad de palabrasincluyendo espacios / /
$num_pares =array("2","4","6");
$num_impares =array("1","3","5");
$numeros =array_merge($num_pares,$num_impares);
print_r($numeros);

echo"verifica valores vacios<br>";
$nombre = null;
if(isset($nombre))
{
echo" IF la variable nombre ->".$nombre ;
}
else{
    echo" ELSE la variable nombre ->".$nombre ;
}
echo"<br> funcion explode <br>";

$colores = "rojo,amarillo,verde";
$array_color= explode(",", $colores);
print_r($array_color);
//son las funciones del sistema 
function saludar($nombre){
    echo "Hola  $nombre <br>";
}
echo "<br> Funcion Saludar <br>";
saludar("Maria");
function sumar($a,$b){
$resultado =$a+$b;
return $resultado;
}
echo "<br>Funcion suma <br>";
echo "La suma es =".sumar(4,6)."<br>";

function longitud_cadena($cadena){
    return strlen($cadena)
    ;
    }
    echo "<br>Funcion Cadena es <br>";
    echo "La longitud cadena es  =".longitud_cadena("4,6")."<br>";
    
    
    
?>
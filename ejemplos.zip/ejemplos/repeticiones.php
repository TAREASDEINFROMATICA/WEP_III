<?php

for($i=1;$i<=10;$i++)
{
    echo "Valor i -> $i <br>"; 
}
echo"<br>";
for($i=10;$i>0;$i--)
{
    echo "Valor i -> $i <br>"; 
}
// while 

$j=1;
while($j<10)
{
    echo "Valor i -> $j <br>"; 
    $j++;
}
echo"------------------------ <br>";

$j=1;

while($j<10)
{
    if($j == "5")
    {
        echo "Valor i -> $j <br> TERMINA EL SICLO <br>"; 
        break;
    }
    echo "Valor i -> $j <br>"; 
    $j++;
}
echo "------------------<br>";

$j=0;
    do{
        echo "Valor i -> $j <br>"; 
    $j++;
        
    }while($j<10);
    echo "----------------<br>";
    $pares= array("Monitor"=> "LG", "Teclado"=>"Lenovo","Teclado","CPU"=>"Pc");
    foreach($pares as  $parte => $marca){
        echo "Valor  --> $parte -> $marca <br>"; 
    }
    echo "<br>";
    $partes= array(array("parte"=>"Monirtor","marca"=>"LG","precio"=>5),
            array("parte"=>"Monirtor","marca"=>"LG","precio"=>5));

    foreach($partes as  $parte){
        echo "Valor  --> parte.>".$parte["parte"].";Marca".$parte["marca"].";precio".$parte["precio"]."<br>"; 
    }
    $cadene1='Hola';
    $cadene2='HOLA';
    if(strcasecmp($cadene1,$cadene2)==0)
    {
        echo "son iguales <br>";
    }
    else{
        echo "son distintos <br>";
    }    
    $cadene1='Hola Como Estas';
    $cadene2='HOLA';
    echo" biscamos en comun <br>";
    if(stripos($cadene1,$cadene2) !== false)
    {
        echo "Encontro la casdena 2 <br>";
    }
    else{
        echo"No encontri nada <br>";
    }

?>
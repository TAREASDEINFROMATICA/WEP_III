<?php
$resultado = 0;
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $valorA= $_POST['valorA'];
    $valorB= $_POST['valorB'];
    $ope=$_POST['ope'];
    //echo $valorA."-".$valorB."-ope- ".$ope;
    if($ope === "sumar"){
        $resultado = $valorA + $valorB;
        //echo $resultado;
    
    }elseif ($ope === "restar"){
        $resultado=$valorA-$valorB;
        //echo $resultado;

    }
}
?>
<html>
    <body>
        <div class="card">
            <form action="" method="post">
            <label for="">CALCULADORA CASIO</label>
            <br>

            <input type="number" name="valorA" id="valorA" value="<?php echo(isset($_POST[$valorA])? $_POST["valorA"]:0 )?> ">
            <br>
            <input type="number" name="valorB" id="valorB" value="<?php echo(isset($_POST[$valorB])? $_POST["valorB"]:0 )?> ">
            <br>
            <select name="ope" id="ope">
                <option value="sumar">Sumar </option>
                <option value="restar">Restar </option>
            </select >
            <br>
            Resultado: <?php echo $resultado; ?> <br>
        
            

            <button type="reset">Limpiar</button>
            <button type="submit">Calcular</button>

            </form>
        </div>
    
    </body>
</html>

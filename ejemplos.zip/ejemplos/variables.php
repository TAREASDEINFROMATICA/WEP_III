<?php
$nombre="Pablo";
$edad = 25;
$ahorros= 98.99;
$cuenta=true;
$saludo=""; 
$hora =14;
$estado_civil="S";
$leyenda="";
if($hora<12)
{
    $saludo ="Buenos dias";

}
elseif($hora<18){
    $saludo="Bunas tardes";
}
else{
    $saludo="BUENAS NOCHES";
}
switch($estado_civil){ //este es el case los shuich-
    case "S":
    $leyenda="Soltera";
        break;
    case "C":
        $leyenda="Casada";
        break;
    case "D":
        $leyenda="Divorciada";
        break;
    default:
        $leyenda="no definida";
        break;


}

echo $saludo .$nombre."Mi edad es de: ".$edad." AÑOS". " su saldo de su cuenta bancaria es  : ".$ahorros."u cuenta se encuentra en estado :".$cuenta.($cuenta?"Activa":"No ACTIVA")."ESTADO CIBIL" .$leyenda;
//los if en php  se llama condidion
echo "<h1>hola mundo</h1>";

?>

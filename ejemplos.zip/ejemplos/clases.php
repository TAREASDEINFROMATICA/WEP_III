<?php
//funciones,metodos
class Vehiculo{
   public $marca;
   //si es private tenemos qe crear nuestros metodos gettes y settesr

   public $modelo;
   public function _construct($marca,$modelo){
    $this->marca =$marca;
    $this->modelo =$modelo;
   }
   public function mostrar(){
    echo "Vehiculo <br>";
    echo"{marca:",$this->marca.";modelo:".$this->modelo."}<br>";

   }

}
class Coche extends Vehiculo
{//coche extiende del veiculo 
    public $placa;
    public function _construct($marca, $modelo, $placa){
        parent::_construct($marca, $modelo);
        $this-> placa=$placa;
    }
    public function mostrar()
    {
        parent::mostrar();
        echo"{placa:".$this->placa."}<br>";
    }
}
class Minibus extends Coche{
    public $linea;
    function _construct($marca, $modelo, $placa, $linea)
    {
        parent::_construct($marca,$modelo,$placa);
        $this-> linea= $linea;
       
    }
    public function mostrar()
    {
        parent::mostrar();
        echo"{lenea:". $this->linea. "}<br>";
    }
}
$minibus248 = new Minibus("TOYOTA","2008","ABC-123","Litoral");
$minibus248->mostrar();

?>